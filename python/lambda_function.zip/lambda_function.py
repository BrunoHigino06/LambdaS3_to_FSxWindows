import boto3
import os
import shutil

s3 = boto3.resource('s3')

def lambda_handler(event, context):
    destination = os.getenv('destination')
    source = os.getenv('source')
    file_name = event['Records'][0]['s3']['object']['key']
    s3.meta.client.download_file(source, file_name, f'/tmp/{file_name}')

    original = r'/tmp/{file_name}'
    target = r'\\\\44.203.144.203\\C:\\{file_name}'

    shutil.copyfile(original, target)